use clap::Parser;

use std::sync::Arc;
use tokio::net::TcpListener;
use tokio_rustls::TlsAcceptor;
use tracing::{info, error, debug, Level};
use tracing_subscriber::FmtSubscriber;

pub mod tls;
pub mod proxy;

#[derive(Parser, Debug)]
#[command(
    name = "NEW ERA PROXY",
    version = "1.0.0",
    about = "O mais avançado Proxy SSH/SSL/Websocket em Rust (NEW ERA PROXY)",
    long_about = "Desenvolvido com o que há de mais avançado em concorrência assíncrona com Rust (Tokio, Rustls e dynamic protocol sniffing)."
)]
struct Args {
    /// Porta para escutar (Recomendado: 80 para HTTP e 443 para SSL)
    #[arg(short, long, default_value_t = 80)]
    port: u16,

    /// Ativar criptografia SSL/TLS (Terminação TLS local)
    #[arg(short, long)]
    ssl: bool,

    /// Caminho do certificado SSL (PEM)
    #[arg(long, default_value = "/etc/neweraproxy/cert.pem")]
    ssl_cert: String,

    /// Caminho da chave privada SSL (PEM)
    #[arg(long, default_value = "/etc/neweraproxy/key.pem")]
    ssl_key: String,

    /// Mensagem de status personalizada para handshakes HTTP/Websocket
    #[arg(long, default_value = "NEW ERA PROXY")]
    status: String,

    /// Porta do servidor SSH local
    #[arg(long, default_value_t = 22)]
    ssh_port: u16,

    /// Porta do servidor OpenVPN local
    #[arg(long, default_value_t = 1194)]
    vpn_port: u16,

    /// WebSocket Path opcional (Exemplo: /ws) para filtrar conexões
    #[arg(long)]
    ws_path: Option<String>,

    /// Resposta HTTP customizada para handshakes (Sobrescreve o handshake padrão se definido)
    #[arg(long)]
    custom_response: Option<String>,
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    // Configura o sistema de logs/tracing
    let subscriber = FmtSubscriber::builder()
        .with_max_level(Level::INFO)
        .with_target(false)
        .finish();
    tracing::subscriber::set_global_default(subscriber)?;

    let args = Args::parse();

    let bind_addr = format!("[::]:{}", args.port);
    let listener = match TcpListener::bind(&bind_addr).await {
        Ok(l) => l,
        Err(e) => {
            error!("Não foi possível escutar na porta {}: {}", args.port, e);
            std::process::exit(1);
        }
    };

    info!("===============================================");
    info!("          🚀 NEW ERA PROXY - INICIADO          ");
    info!("===============================================");
    info!("📍 Escutando em: {}", bind_addr);
    info!("⚙️ Porta SSH local: {}", args.ssh_port);
    info!("⚙️ Porta VPN local: {}", args.vpn_port);
    info!("💬 Status Handshake: \"{}\"", args.status);
    if let Some(ref path) = args.ws_path {
        info!("🛣️ WS Path ativado: {}", path);
    }
    if args.ssl {
        info!("🔒 Criptografia SSL/TLS ATIVADA");
        info!("📜 Certificado: {}", args.ssl_cert);
        info!("🔑 Chave Privada: {}", args.ssl_key);
    } else {
        info!("🔓 Modo Plain TCP / HTTP WS ATIVADO");
    }
    info!("===============================================");

    let status = Arc::new(args.status);
    let ws_path = Arc::new(args.ws_path);
    let custom_response = Arc::new(args.custom_response);

    if args.ssl {
        // Build TLS config (creates self-signed certificates if missing)
        let tls_config = match tls::create_tls_config(&args.ssl_cert, &args.ssl_key) {
            Ok(cfg) => cfg,
            Err(e) => {
                error!("Erro ao carregar ou gerar certificados SSL: {}", e);
                std::process::exit(1);
            }
        };
        let acceptor = TlsAcceptor::from(tls_config);

        loop {
            match listener.accept().await {
                Ok((client_stream, addr)) => {
                    let acceptor = acceptor.clone();
                    let status = status.clone();
                    let ws_path = ws_path.clone();
                    let custom_response = custom_response.clone();
                    let ssh_port = args.ssh_port;
                    let vpn_port = args.vpn_port;

                    tokio::spawn(async move {
                        debug!("[{}] Conexão recebida. Iniciando TLS Handshake...", addr);
                        match acceptor.accept(client_stream).await {
                            Ok(tls_stream) => {
                                debug!("[{}] TLS Handshake bem-sucedido.", addr);
                                if let Err(e) = proxy::handle_client(
                                    tls_stream,
                                    addr,
                                    (*status).clone(),
                                    ssh_port,
                                    vpn_port,
                                    (*ws_path).clone(),
                                    (*custom_response).clone(),
                                ).await {
                                    debug!("[{}] Conexão encerrada com erro: {}", addr, e);
                                }
                            }
                            Err(e) => {
                                error!("[{}] Falha no TLS Handshake: {}", addr, e);
                            }
                        }
                    });
                }
                Err(e) => {
                    error!("Erro ao aceitar conexão TCP (SSL): {}", e);
                }
            }
        }
    } else {
        // Plain TCP Listener (No SSL)
        loop {
            match listener.accept().await {
                Ok((client_stream, addr)) => {
                    let status = status.clone();
                    let ws_path = ws_path.clone();
                    let custom_response = custom_response.clone();
                    let ssh_port = args.ssh_port;
                    let vpn_port = args.vpn_port;

                    tokio::spawn(async move {
                        if let Err(e) = proxy::handle_client(
                            client_stream,
                            addr,
                            (*status).clone(),
                            ssh_port,
                            vpn_port,
                            (*ws_path).clone(),
                            (*custom_response).clone(),
                        ).await {
                            debug!("[{}] Conexão encerrada com erro: {}", addr, e);
                        }
                    });
                }
                Err(e) => {
                    error!("Erro ao aceitar conexão TCP: {}", e);
                }
            }
        }
    }
}
