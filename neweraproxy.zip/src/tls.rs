use std::fs::{self, File};
use std::io::{self, BufReader};
use std::path::Path;
use std::sync::Arc;
use tracing::{info, warn};

use tokio_rustls::rustls::ServerConfig;
use tokio_rustls::rustls::pki_types::{CertificateDer, PrivateKeyDer};

// Generate self-signed certificate and private key if not exists
pub fn ensure_certificates<P: AsRef<Path>>(cert_path: P, key_path: P) -> io::Result<()> {
    let cert_path = cert_path.as_ref();
    let key_path = key_path.as_ref();

    if cert_path.exists() && key_path.exists() {
        info!("Certificados SSL encontrados: {:?} e {:?}", cert_path, key_path);
        return Ok(());
    }

    warn!("Certificados SSL não encontrados. Gerando certificados autoassinados...");

    // Create directories if they do not exist
    if let Some(parent) = cert_path.parent() {
        fs::create_dir_all(parent)?;
    }
    if let Some(parent) = key_path.parent() {
        fs::create_dir_all(parent)?;
    }

    // Generate with rcgen
    let subject_alt_names = vec![
        "localhost".to_string(),
        "127.0.0.1".to_string(),
        "0.0.0.0".to_string(),
    ];

    let rcgen::CertifiedKey { cert, key_pair } = rcgen::generate_simple_self_signed(subject_alt_names)
        .map_err(|e| io::Error::new(io::ErrorKind::Other, format!("rcgen error: {}", e)))?;

    let cert_pem = cert.pem();
    let key_pem = key_pair.serialize_pem();

    fs::write(cert_path, cert_pem)?;
    fs::write(key_path, key_pem)?;

    info!("Certificados autoassinados gerados com sucesso!");
    Ok(())
}

// Load certificates from PEM files
pub fn load_certs<P: AsRef<Path>>(path: P) -> io::Result<Vec<CertificateDer<'static>>> {
    let file = File::open(path)?;
    let mut reader = BufReader::new(file);
    let certs = rustls_pemfile::certs(&mut reader)
        .collect::<Result<Vec<_>, _>>()?;
    Ok(certs)
}

// Load private key from PEM file
pub fn load_key<P: AsRef<Path>>(path: P) -> io::Result<PrivateKeyDer<'static>> {
    let file = File::open(path)?;
    let mut reader = BufReader::new(file);
    let key = rustls_pemfile::private_key(&mut reader)?
        .ok_or_else(|| io::Error::new(io::ErrorKind::NotFound, "Chave privada não encontrada no arquivo"))?;
    Ok(key)
}

// Build standard TLS server configuration
pub fn create_tls_config<P: AsRef<Path>>(cert_path: P, key_path: P) -> io::Result<Arc<ServerConfig>> {
    ensure_certificates(&cert_path, &key_path)?;

    let certs = load_certs(cert_path)?;
    let key = load_key(key_path)?;

    let config = ServerConfig::builder()
        .with_no_client_auth()
        .with_single_cert(certs, key)
        .map_err(|e| io::Error::new(io::ErrorKind::InvalidInput, format!("Erro de config do rustls: {}", e)))?;

    Ok(Arc::new(config))
}
