use std::time::Duration;
use tokio::io::{AsyncReadExt, AsyncWriteExt, copy_bidirectional};
use tokio::net::TcpStream;
use tokio::time::timeout;
use tracing::{info, error, debug};

/// Handles an incoming client connection (either plain TCP or decrypted TLS stream).
/// It dynamically detects the protocol and performs custom injection handshakes if needed.
pub async fn handle_client<S>(
    mut client_stream: S,
    addr: std::net::SocketAddr,
    status: String,
    ssh_port: u16,
    vpn_port: u16,
    ws_path: Option<String>,
    custom_response: Option<String>,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>>
where
    S: tokio::io::AsyncRead + tokio::io::AsyncWrite + Unpin + Send + 'static,
{
    let mut buf = vec![0u8; 2048];
    let mut bytes_read = 0;

    // Sniff the initial bytes from the client to detect protocol (500ms timeout)
    let read_result = timeout(Duration::from_millis(500), client_stream.read(&mut buf)).await;
    match read_result {
        Ok(Ok(n)) => {
            bytes_read = n;
        }
        Ok(Err(e)) => {
            error!("[{}] Erro na leitura inicial: {}", addr, e);
            return Err(Box::new(e));
        }
        Err(_) => {
            // Timeout: Client is silent (waiting for server, e.g., SSH or OpenVPN)
            debug!("[{}] Timeout na leitura inicial. Usando rota padrão.", addr);
        }
    }

    let initial_data = &buf[..bytes_read];
    let request_str = String::from_utf8_lossy(initial_data);

    let is_http = request_str.starts_with("GET")
        || request_str.starts_with("POST")
        || request_str.starts_with("CONNECT")
        || request_str.starts_with("PUT")
        || request_str.starts_with("OPTIONS")
        || request_str.starts_with("HEAD")
        || request_str.contains("HTTP/");

    let target_port; // will be determined dynamically

    if is_http {
        debug!("[{}] HTTP Detectado. Analisando cabeçalhos...", addr);

        // Optional WebSockets path check
        if let Some(ref path) = ws_path {
            let path_header = format!(" {}", path);
            if !request_str.contains(&path_header) {
                info!("[{}] Requisição HTTP não corresponde ao WS path: {}. Rejeitando.", addr, path);
                let response = "HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\nContent-Length: 9\r\n\r\nNot Found";
                client_stream.write_all(response.as_bytes()).await?;
                return Ok(());
            }
        }

        // Perform Handshake
        if let Some(ref custom_resp) = custom_response {
            // Send custom response payload
            client_stream.write_all(custom_resp.as_bytes()).await?;
        } else {
            // Legacy triple handshake for SSH WebSocket/Injectors
            // 1. First 101 Response
            client_stream
                .write_all(format!("HTTP/1.1 101 {}\r\n\r\n", status).as_bytes())
                .await?;

            // 2. Read next injector packet
            let mut second_buf = vec![0u8; 1024];
            let _ = timeout(Duration::from_secs(5), client_stream.read(&mut second_buf)).await;

            // 3. Second 101 and final 200 responses
            client_stream
                .write_all(format!("HTTP/1.1 101 {}\r\n\r\n", status).as_bytes())
                .await?;
            client_stream
                .write_all(format!("HTTP/1.1 200 {}\r\n\r\n", status).as_bytes())
                .await?;
        }

        // After the HTTP WebSocket handshake, read the actual payload start
        let mut payload_buf = vec![0u8; 1024];
        let mut payload_bytes = 0;
        if let Ok(Ok(n)) = timeout(Duration::from_millis(500), client_stream.read(&mut payload_buf)).await {
            payload_bytes = n;
        }

        let payload_str = String::from_utf8_lossy(&payload_buf[..payload_bytes]);
        if payload_str.contains("SSH") || payload_bytes == 0 {
            target_port = ssh_port;
            info!("[{}] Handshake HTTP concluído. Roteando para SSH (porta {}).", addr, target_port);
        } else {
            target_port = vpn_port;
            info!("[{}] Handshake HTTP concluído. Roteando para VPN (porta {}).", addr, target_port);
        }

        // Connect to local backend
        let mut target_stream = match TcpStream::connect(format!("127.0.0.1:{}", target_port)).await {
            Ok(stream) => stream,
            Err(e) => {
                error!("[{}] Falha ao conectar ao backend na porta {}: {}", addr, target_port, e);
                return Err(Box::new(e));
            }
        };

        // Write any initial payload bytes to target
        if payload_bytes > 0 {
            target_stream.write_all(&payload_buf[..payload_bytes]).await?;
        }

        // Bidirectional bridge
        let _ = copy_bidirectional(&mut client_stream, &mut target_stream).await;

    } else {
        // Direct non-HTTP traffic (Direct SSH, Direct OpenVPN, SSL SNI etc.)
        if request_str.starts_with("SSH") {
            target_port = ssh_port;
            info!("[{}] Conexão SSH Direta detectada. Roteando para SSH (porta {}).", addr, target_port);
        } else {
            // Standard fallback
            target_port = ssh_port;
            debug!("[{}] Tráfego desconhecido ou silencioso. Roteando para porta padrão ({}).", addr, target_port);
        }

        // Connect to local backend
        let mut target_stream = match TcpStream::connect(format!("127.0.0.1:{}", target_port)).await {
            Ok(stream) => stream,
            Err(e) => {
                error!("[{}] Falha ao conectar ao backend na porta {}: {}", addr, target_port, e);
                return Err(Box::new(e));
            }
        };

        // Forward initial sniffed bytes if any
        if bytes_read > 0 {
            target_stream.write_all(initial_data).await?;
        }

        // Bidirectional bridge
        let _ = copy_bidirectional(&mut client_stream, &mut target_stream).await;
    }

    Ok(())
}
